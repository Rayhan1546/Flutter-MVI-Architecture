package com.example.github_repo_list

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
