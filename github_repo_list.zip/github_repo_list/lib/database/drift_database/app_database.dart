/*
import 'package:drift/drift.dart';
import 'package:github_repo_list/database/drift_database/github_table.dart';
import 'package:github_repo_list/domain/model/repository.dart';

part 'app_database.g.dart';

@DriftDatabase(tables: [GithubTable])
class AppDatabase extends _$AppDatabase {
  AppDatabase(QueryExecutor e) : super(e);

  @override
  int get schemaVersion => 1;

  // Add your database queries here (DAO methods)
  Future<List<Repository>> getAllRepositories() async {
    final query = select(githubTable);
    final results = await query.get();
    return results.map((e) => Repository.fromData(e.toMap())).toList();
  }

  Future<int> insertRepository(Repository repository) async {
    final insert = into(githubTa).insert(
      GithubTableCompanion(
        name: Value(repository.name),
        imgUrl: Value(repository.imgUrl),
        description: Value(repository.description),
      ),
    );
    return await insert;
  }

  Future<int> updateRepository(Repository repository) async {
    return await update(githubTable).replace(
      GithubTableCompanion(
        id: Value(repository.id),
        name: Value(repository.name),
        imgUrl: Value(repository.imgUrl),
        description: Value(repository.description),
      ),
    );
  }

  Future<int> deleteRepository(int id) async {
    return await (delete(githubTable)..where((t) => t.id.equals(id))).go();
  }
}
*/
