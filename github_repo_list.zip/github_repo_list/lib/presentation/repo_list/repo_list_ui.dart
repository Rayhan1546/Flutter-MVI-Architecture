import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:github_repo_list/presentation/repo_list/repo_list_view_model.dart';

class RepoListUi extends StatelessWidget {
  const RepoListUi({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("GitHub Repositories"),
      ),
      body: ChangeNotifierProvider(
        create: (_) => RepoListViewModel(),
        child: Consumer<RepoListViewModel>(
          builder: (context, viewModel, child) {
            if (viewModel.gitRepository.isEmpty) {
              return const Center(child: CircularProgressIndicator());
            }

            return ListView.builder(
              itemCount: viewModel.gitRepository.length,
              itemBuilder: (context, index) {
                final repository = viewModel.gitRepository[index];

                return Card(
                  margin: const EdgeInsets.all(8.0),
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(10.0),
                    leading: repository.imgUrl.isNotEmpty
                        ? CircleAvatar(
                      backgroundImage: NetworkImage(repository.imgUrl),
                    )
                        : const CircleAvatar(child: Icon(Icons.person)),
                    title: Text(repository.name),
                    subtitle: Text(repository.description),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
