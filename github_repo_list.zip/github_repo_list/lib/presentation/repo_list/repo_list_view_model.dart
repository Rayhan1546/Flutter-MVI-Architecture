import 'package:flutter/cupertino.dart';
import 'package:github_repo_list/data/repository/github_repository_impl.dart';
import 'package:github_repo_list/domain/model/repository.dart';
import 'package:github_repo_list/domain/repository/github_repository.dart';

class RepoListViewModel extends ChangeNotifier {
  RepoListViewModel() {
    fetchRepositories();
  }

  GithubRepository githubRepository = GithubRepositoryImpl();

  late List<Repository> _gitRepository = [];
  List<Repository> get gitRepository => _gitRepository;

  Future<void> fetchRepositories() async {
    _gitRepository = await githubRepository.getGithubRepository();
    notifyListeners();
  }
}
