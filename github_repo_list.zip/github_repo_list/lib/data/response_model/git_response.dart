class OwnerResponse {
  final String login;
  final int id;
  final String nodeId;
  final String avatarUrl;
  final String gravatarId;
  final String url;
  final String htmlUrl;
  final String followersUrl;
  final String followingUrl;
  final String gistsUrl;
  final String starredUrl;
  final String subscriptionsUrl;
  final String organizationsUrl;
  final String reposUrl;
  final String eventsUrl;
  final String receivedEventsUrl;
  final String type;
  final String userViewType;
  final bool siteAdmin;

  OwnerResponse({
    required this.login,
    required this.id,
    required this.nodeId,
    required this.avatarUrl,
    required this.gravatarId,
    required this.url,
    required this.htmlUrl,
    required this.followersUrl,
    required this.followingUrl,
    required this.gistsUrl,
    required this.starredUrl,
    required this.subscriptionsUrl,
    required this.organizationsUrl,
    required this.reposUrl,
    required this.eventsUrl,
    required this.receivedEventsUrl,
    required this.type,
    required this.userViewType,
    required this.siteAdmin,
  });

  factory OwnerResponse.fromJson(Map<String, dynamic> json) {
    return OwnerResponse(
      login: json['login'] ?? '', // Default to empty string if null
      id: json['id'] ?? 0, // Default to 0 if null
      nodeId: json['node_id'] ?? '', // Default to empty string if null
      avatarUrl: json['avatar_url'] ?? '', // Default to empty string if null
      gravatarId: json['gravatar_id'] ?? '', // Default to empty string if null
      url: json['url'] ?? '', // Default to empty string if null
      htmlUrl: json['html_url'] ?? '', // Default to empty string if null
      followersUrl: json['followers_url'] ?? '', // Default to empty string if null
      followingUrl: json['following_url'] ?? '', // Default to empty string if null
      gistsUrl: json['gists_url'] ?? '', // Default to empty string if null
      starredUrl: json['starred_url'] ?? '', // Default to empty string if null
      subscriptionsUrl: json['subscriptions_url'] ?? '', // Default to empty string if null
      organizationsUrl: json['organizations_url'] ?? '', // Default to empty string if null
      reposUrl: json['repos_url'] ?? '', // Default to empty string if null
      eventsUrl: json['events_url'] ?? '', // Default to empty string if null
      receivedEventsUrl: json['received_events_url'] ?? '', // Default to empty string if null
      type: json['type'] ?? '', // Default to empty string if null
      userViewType: json['user_view_type'] ?? '', // Default to empty string if null
      siteAdmin: json['site_admin'] ?? false, // Default to false if null
    );
  }
}


class RepositoryResponse {
  final int id;
  final String nodeId;
  final String name;
  final String fullName;
  final bool isPrivate;
  final OwnerResponse owner;
  final String htmlUrl;
  final String description;

  RepositoryResponse({
    required this.id,
    required this.nodeId,
    required this.name,
    required this.fullName,
    required this.isPrivate,
    required this.owner,
    required this.htmlUrl,
    required this.description,
  });

  factory RepositoryResponse.fromJson(Map<String, dynamic> json) {
    return RepositoryResponse(
      id: json['id'] ?? 0, // Default to 0 if null
      nodeId: json['node_id'] ?? '', // Default to empty string if null
      name: json['name'] ?? '', // Default to empty string if null
      fullName: json['full_name'] ?? '', // Default to empty string if null
      isPrivate: json['private'] ?? false, // Default to false if null
      owner: OwnerResponse.fromJson(json['owner'] ?? {}), // Ensure owner is not null and default to empty map if null
      htmlUrl: json['html_url'] ?? '', // Default to empty string if null
      description: json['description'] ?? 'No description available', // Default if null
    );
  }
}
