import 'dart:convert';
import 'package:github_repo_list/data/response_model/git_response.dart';
import 'package:http/http.dart' as http;

class GitHubService {
  static const String baseUrl = 'https://api.github.com/repositories';

  // Function to fetch repositories
  Future<List<RepositoryResponse>> fetchRepositories() async {
    final response = await http.get(Uri.parse(baseUrl));

    if (response.statusCode == 200) {
      // If the server returns a 200 OK response, parse the JSON
      List<dynamic> data = json.decode(response.body);
      return data.map((repoJson) => RepositoryResponse.fromJson(repoJson)).toList();
    } else {
      // If the server returns an error, throw an exception
      throw Exception('Failed to load repositories');
    }
  }
}
