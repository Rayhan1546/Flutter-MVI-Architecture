import 'package:github_repo_list/data/api_client/github_service.dart';
import 'package:github_repo_list/domain/model/repository.dart';
import 'package:github_repo_list/domain/repository/github_repository.dart';

class GithubRepositoryImpl extends GithubRepository {
  GitHubService gitHubService = GitHubService();

  @override
  Future<List<Repository>> getGithubRepository() async {
    final json = await gitHubService.fetchRepositories();

    return json.map((e) => Repository(
              id: e.id,
              name: e.fullName,
              description: e.description,
              imgUrl: e.owner.avatarUrl,
            )).toList();
  }
}
